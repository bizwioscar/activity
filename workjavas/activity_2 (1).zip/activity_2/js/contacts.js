/* 
Activity: Contact manager
*/

// TODO: Complete the program
